<?php include('config/config.php'); ?>
<?php
$q="SELECT * FROM tbl_order ORDER BY order_id DESC";

  $res=mysqli_query($con,$q);
   $total_rows=mysqli_num_rows($res);
?>

<?php include('header.php'); ?>  
    

<h3 align="center">Invoice Management System</h3>

      <br />
      <div align="right">
        <a href="index.php" class="btn btn-info btn-xs">Create</a>
      </div>
      <br />
      <table id="data-table" class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>Invoice No.</th>
            <th>Invoice Date</th>
            <th>Receiver Name</th>
            <th>Invoice Total</th>
            <th>Generate Invoice</th>
          </tr>
        </thead>
        <?php
        if($total_rows > 0)
        {
          while($row=mysqli_fetch_array($res))
          {
          ?>
            
              <tr>
                <td><?php echo $row["order_no"];?></td>
                <td><?php echo $row["order_date"];?></td>
                <td><?php echo $row["order_receiver_name"];?></td>
                <td><?php echo $row["order_total_after_tax"];?></td>
                <td><a href="print_invoice.php?id=<?php echo $row['order_id']?>" target="_blank">Generate Invoice</a></td>
              </tr>
          
         <?php }
        }
        ?>
      </table>