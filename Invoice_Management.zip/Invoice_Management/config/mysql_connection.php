<?php
	include('database.php');
	
	$con=mysqli_connect(HOST_NAME,USER_NAME,PASSWORD,DB_NAME);
	if(mysqli_errno($con))
	{
		die('connection key missing');
	}
?>