<?php
include('mysql_connection.php');
define('BASE_URL','http://localhost/invoice_management/');
define('BASE_PATH','http://localhost/invoice_management/assets/');



?>