<?php
	define("HOST_NAME","localhost");
	define("USER_NAME","root");
	define("PASSWORD","");
	define("DB_NAME","invoice");

?>